library(spgwr)
library(rgeos)
library(ggplot2)
library(maptools)
library(rgdal)
library(GWmodel)
library(ggplot2)
library(maptools)
library(rgdal)
library(readr)
library(spData)
library(psych)
library(GWmodel)
library(spatial)
library(sf)
library(corrplot)
library(car)

install.packages('spDataLarge', repos='https://nowosad.github.io/drat/', type='source')
library(spDataLarge)

setwd("D:\\Documentos")
cardio <- read.csv("banco_XY.csv", sep=",", dec=",")
banco_XY <- read.csv("banco_XY.csv", sep=",", dec=",")
banco_XY$POLY_ID <- c(1:399)

banco_XY$TX_CARDIO <- as.numeric(as.character(banco_XY$TX_CARDIO))
banco_XY$Taxadeen <- as.numeric(as.character(banco_XY$Taxadeen))
banco_XY$razao_rend <- as.numeric(as.character(banco_XY$razao_rend))
banco_XY$prop_eSF_2 <- as.numeric(as.character(banco_XY$prop_eSF_2))
banco_XY$TX_CAT <- as.numeric(as.character(banco_XY$TX_CAT))
banco_XY$TX_CINT<- as.numeric(as.character(banco_XY$TX_CINT))
banco_XY$PTP_CARDIO<- as.numeric(as.character(banco_XY$PTP_CARDIO))
banco_XY$PTP_RQ<- as.numeric(as.character(banco_XY$PTP_RQ))
banco_XY$PTP_HEMO <- as.numeric(as.character(banco_XY$PTP_HEMO))
banco_XY$tx_angio <- as.numeric(as.character(banco_XY$tx_angio))
banco_XY$tx_RQ <- as.numeric(as.character(banco_XY$tx_RQ))
banco_XY$Tx.ECO <- as.numeric(as.character(banco_XY$Tx.ECO))
banco_XY$Tx_ressecc <- as.numeric(as.character(banco_XY$Tx_ressecc))
banco_XY$Tx_esforco <- as.numeric(as.character(banco_XY$Tx_esforco))
banco_XY$analfabeti <- as.numeric(as.character(banco_XY$analfabeti))

head(banco_XY)
summary(banco_XY)
describe(banco_XY)
str(banco_XY)
colnames(banco_XY)
cardiologia <- lm(banco_XY$TX_CARDIO ~ banco_XY$Taxadeen+banco_XY$razao_rend+banco_XY$prop_eSF_2+banco_XY$TX_CAT+banco_XY$TX_CINT+banco_XY$PTP_CARDIO+banco_XY$PTP_RQ+banco_XY$PTP_HEMO+banco_XY$tx_angio+banco_XY$tx_RQ+banco_XY$Tx.ECO+banco_XY$Tx_ressecc+banco_XY$Tx_esforco+banco_XY$analfabeti)
summary(cardiologia) 
vif(cardiologia)  #n�o pode ser maior > 5 � colinear
AIC(cardiologia)
plot(cardiologia, which=3)
residuo <- residuals(cardiologia)
describe (residuo)
banco_XY$predicted <- predict(cardiologia)   # Save the predicted values
banco_XY$residuals <- residuals(cardiologia) # Save the residual values

#construir um moran de residuos aqui da OLS

setwd("D:\\Documentos\\Amanda0310")
cidades <- readShapePoly("PR.shp")
cidades@data$id <- c(1:399)
cidadesDF <- fortify(cidades, region = "id")

GWRfaixa<-gwr.sel(banco_XY$TX_CARDIO ~ banco_XY$Taxadeen+banco_XY$razao_rend+banco_XY$prop_eSF_2+banco_XY$TX_CAT+banco_XY$TX_CINT+banco_XY$PTP_CARDIO+banco_XY$PTP_RQ+banco_XY$PTP_HEMO+banco_XY$tx_angio+banco_XY$tx_RQ+banco_XY$Tx.ECO+banco_XY$Tx_ressecc+banco_XY$Tx_esforco+banco_XY$analfabeti,
                    data=banco_XY, coords=cbind(banco_XY$COORD_X,banco_XY$COORD_Y), adapt = TRUE)
modelo=gwr(banco_XY$TX_CARDIO ~ banco_XY$Taxadeen+banco_XY$razao_rend+banco_XY$prop_eSF_2+banco_XY$TX_CAT+banco_XY$TX_CINT+banco_XY$PTP_CARDIO+banco_XY$PTP_RQ+banco_XY$PTP_HEMO+banco_XY$tx_angio+banco_XY$tx_RQ+banco_XY$Tx.ECO+banco_XY$Tx_ressecc+banco_XY$Tx_esforco+banco_XY$analfabeti,
           data=banco_XY, coords=cbind(banco_XY$COORD_X,banco_XY$COORD_Y),adapt = GWRfaixa, hatmatrix = TRUE, se.fit = TRUE)

modelo2=lm(banco_XY$TX_CARDIO ~ banco_XY$Taxadeen+banco_XY$razao_rend+banco_XY$prop_eSF_2+banco_XY$TX_CAT+banco_XY$TX_CINT+banco_XY$PTP_CARDIO+banco_XY$PTP_RQ+banco_XY$PTP_HEMO+banco_XY$tx_angio+banco_XY$tx_RQ+banco_XY$Tx.ECO+banco_XY$Tx_ressecc+banco_XY$Tx_esforco+banco_XY$analfabeti,
           data=banco_XY)


modelo
resultadogeoregress <- as.data.frame(modelo$SDF)
head(resultadogeoregress)

##

cidades@data$coefTaxadeen <- resultadogeoregress$banco_XY.Taxadeen
cidades@data$coefrazao_rend <- resultadogeoregress$banco_XY.razao_rend
cidades@data$coefprop_eSF_2 <- resultadogeoregress$banco_XY.prop_eSF_2
cidades@data$coefTX_CAT<- resultadogeoregress$banco_XY.TX_CAT
cidades@data$coefTX_CINT <- resultadogeoregress$banco_XY.TX_CINT
cidades@data$coefPTP_CARDIO  <- resultadogeoregress$banco_XY.PTP_CARDIO
cidades@data$coefPTP_RQ <- resultadogeoregress$banco_XY.PTP_RQ
cidades@data$coefPTP_HEMO <- resultadogeoregress$banco_XY.PTP_HEMO
cidades@data$coeftx_angio <- resultadogeoregress$banco_XY.tx_angio
cidades@data$coeftx_RQ  <- resultadogeoregress$banco_XY.tx_RQ 
cidades@data$coefTx.ECO <- resultadogeoregress$banco_XY.Tx.ECO
cidades@data$coefTx_ressecc <- resultadogeoregress$banco_XY.Tx_ressecc
cidades@data$coefTx_esforco <- resultadogeoregress$banco_XY.Tx_esforco
cidades@data$coefanalfabeti<- resultadogeoregress$banco_XY.analfabeti

cidades@data$coefTaxadeenig <- resultadogeoregress$banco_XY.Taxadeen/resultadogeoregress$banco_XY.Taxadeen_se
cidades@data$coefrazao_rendig <- resultadogeoregress$banco_XY.razao_rend/resultadogeoregress$banco_XY.razao_rend_se
cidades@data$coefprop_eSF_2ig <- resultadogeoregress$banco_XY.prop_eSF_2/resultadogeoregress$banco_XY.prop_eSF_2_se
cidades@data$coefTX_CATig <- resultadogeoregress$banco_XY.TX_CAT/resultadogeoregress$banco_XY.TX_CAT_se
cidades@data$coefTX_CINTig <- resultadogeoregress$banco_XY.TX_CINT/resultadogeoregress$banco_XY.TX_CINT_se
cidades@data$coefPTP_CARDIOig  <- resultadogeoregress$banco_XY.PTP_CARDIO/resultadogeoregress$banco_XY.PTP_CARDIO_se
cidades@data$coefPTP_RQig <- resultadogeoregress$banco_XY.PTP_RQ/resultadogeoregress$banco_XY.PTP_RQ_se
cidades@data$coefPTP_HEMOig <- resultadogeoregress$banco_XY.PTP_HEMO/resultadogeoregress$banco_XY.PTP_HEMO_se
cidades@data$coeftx_angioig <- resultadogeoregress$banco_XY.tx_angio/resultadogeoregress$banco_XY.tx_angio_se
cidades@data$coeftx_RQig  <- resultadogeoregress$banco_XY.tx_RQ/resultadogeoregress$banco_XY.tx_RQ_se 
cidades@data$coefTx.ECOig <- resultadogeoregress$banco_XY.Tx.ECO/resultadogeoregress$banco_XY.Tx.ECO_se
cidades@data$coefTx_resseccig <- resultadogeoregress$banco_XY.Tx_ressecc/resultadogeoregress$banco_XY.Tx_ressecc_se
cidades@data$coefTx_esforcoig <- resultadogeoregress$banco_XY.Tx_esforco/resultadogeoregress$banco_XY.Tx_esforco_se
cidades@data$coefanalfabetiig<- resultadogeoregress$banco_XY.analfabeti/resultadogeoregress$banco_XY.analfabeti_se

cidades@data$coefTaxadeenp <- round(2 * (1 - pt(abs(cidades@data$coefTaxadeenig), 89.9)), 3)
cidades@data$coefrazao_rendip <- round(2 * (1 - pt(abs(cidades@data$coefrazao_rendig), 89.9)), 3)
cidades@data$coefprop_eSF_2p <- round(2 * (1 - pt(abs(cidades@data$coefprop_eSF_2ig), 89.9)), 3)
cidades@data$coefTX_CATp <- round(2 * (1 - pt(abs(cidades@data$coefTX_CATig), 89.9)), 3)
cidades@data$coefTX_CINTp <- round(2 * (1 - pt(abs(cidades@data$coefTX_CINTig ), 89.9)), 3)
cidades@data$coefPTP_CARDIOp <- round(2 * (1 - pt(abs(cidades@data$coefPTP_CARDIOig), 89.9)), 3)
cidades@data$coefPTP_RQp <- round(2 * (1 - pt(abs(cidades@data$coefPTP_RQig), 89.9)), 3)
cidades@data$coefPTP_HEMOp <- round(2 * (1 - pt(abs(cidades@data$coefPTP_HEMOig), 89.9)), 3)
cidades@data$coeftx_angiop <- round(2 * (1 - pt(abs(cidades@data$coeftx_angioig ), 89.9)), 3)
cidades@data$coeftx_RQp <- round(2 * (1 - pt(abs(cidades@data$coeftx_RQig), 89.9)), 3)
cidades@data$coefTx.ECOp<- round(2 * (1 - pt(abs(cidades@data$coefTx.ECOig), 89.9)), 3)
cidades@data$coefTx_resseccp<- round(2 * (1 - pt(abs(cidades@data$coefTx_resseccig  ), 89.9)), 3)
cidades@data$coefTx_esforcop<- round(2 * (1 - pt(abs(cidades@data$coefTx_esforcoig), 89.9)), 3)
cidades@data$coefanalfabetip <- round(2 * (1 - pt(abs(cidades@data$coefanalfabetiig), 89.9)), 3)


writeOGR(cidades,"D:\\Documentos\\Amanda0310", layer = "GWR_CARDIO_R",driver = "ESRI Shapefile")
cidadesDF <-merge(cidadesDF, cidades@data, by="id")


##END#####


#moran Residuo OLS
residuals<-lm.morantest(modelo2,W)
summary(residuals)

head(modelo)
resi<-gwr.morantest(modelolm$residuals,W)
residuos<-gwr.morantest(modelo@lm$residuals)


library(gwr.morantest)
GWRresi <- gwr.morantest(modelo, W,hatmatrix=TRUE)

GWRresi <- gwr.morantest(modelo, W, zero.policy = FALSE)

summary(modelo)

#MATRIx
library(spdep)
queen.nb <- poly2nb(cidades, queen = TRUE, row.names = cidades$municipio)
W <-nb2listw(queen.nb, style="W", zero.policy=TRUE)